#ifndef MAGE_H
#define MAGE_H

#include <string>
#include <vector>
#include "Carte.h"

class Mage{
  protected:
    int _pointsDeVie;
    std::string _name;
    int _manaTotal;
    int _mana;
    std::vector<Carte*> _hand;
    std::vector<Carte*> _board;
    std::vector<Carte*> _bin;
  public:
    void affichePartie();
    Mage(int pv, std::string nom, std::vector<Carte*> cartesEnMain);
    void playCard(int indexDansLaMain);
    void regainMana();
};


#endif