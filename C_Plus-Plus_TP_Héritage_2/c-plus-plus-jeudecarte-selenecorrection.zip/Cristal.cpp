#ifndef CRISTAL_CPP
#define CRISTAL_CPP

#include <string>
#include "Carte.h"
#include "Cristal.h"
#include <iostream>

// int _manaCost;  std::string _name; std::string _flavorText;
// _value;

    void Cristal::affiche(){
        std::cout << _name << " est un Cristal décrit comme " << _flavorText 
        << ", coûtant " << _manaCost << " et de valeur " << _value << "." << std::endl;
    }
    
    Cristal::Cristal(int cout, std::string nom, std::string description, int valeur):
    Carte(cout, nom, description), _value(valeur) {}


#endif