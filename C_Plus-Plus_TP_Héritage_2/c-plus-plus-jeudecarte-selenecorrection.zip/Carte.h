#ifndef CARTE_H
#define CARTE_H

#include <string>

class Carte{
  protected:
    int _manaCost;
    std::string _name;
    std::string _flavorText;
  public:
    void virtual affiche();
    Carte(int cout, std::string nom, std::string description);
    int getCost();
};


#endif