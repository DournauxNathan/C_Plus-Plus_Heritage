#ifndef CARTE_CPP
#define CARTE_CPP

#include <string>
#include "Carte.h"
#include <iostream>

// int _manaCost;  std::string _name; std::string _flavorText;

    void Carte::affiche(){
        std::cout << "Ceci est une Carte sans type !!!" << std::endl;
    }
    
    Carte::Carte(int cout, std::string nom, std::string description):
        _manaCost(cout), _name(nom), _flavorText(description) {}
    
    int Carte::getCost(){
        return _manaCost;
    }
    
#endif