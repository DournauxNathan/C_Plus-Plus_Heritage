#ifndef CRISTAL_H
#define CRISTAL_H

#include <string>
#include "Carte.h"

class Cristal : public Carte{
  private:
    int _value;
  public:
    void affiche();
    Cristal(int cout, std::string nom, std::string description, int valeur);
};


#endif