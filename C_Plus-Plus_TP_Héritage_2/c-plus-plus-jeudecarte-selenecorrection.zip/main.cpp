#include <iostream>
#include "Carte.h"
#include "Mage.h"
#include "Cristal.h"
#include <vector>

using namespace std;

int main()
{
    
    Cristal * cristalDeDepart = new Cristal(0, "Cristal basique", "Un cristal très simple...", 1);
    cristalDeDepart->affiche();
    
    Mage * gandalf = new Mage(20,"Gandalf", vector<Carte*>(1, cristalDeDepart));
    gandalf->affichePartie();
    return 0;
}
