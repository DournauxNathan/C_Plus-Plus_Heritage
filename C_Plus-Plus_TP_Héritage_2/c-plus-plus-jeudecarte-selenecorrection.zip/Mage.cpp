#ifndef MAGE_CPP
#define MAGE_CPP

#include <string>
#include <vector>
#include <iostream>
#include "Mage.h"

//int _pointsDeVie;std::string _name;int _manaTotal;int _mana;
// vector<Carte> _hand;vector<Carte> _board;vector<Carte> _bin;

    void Mage::affichePartie(){
        std::cout << _name << " possède " << _pointsDeVie << " points de vie, " << _mana <<
        "/" << _manaTotal << " poins de mana.";
        _hand[0]->affiche();
    }
    
    Mage::Mage(int pv, std::string nom, std::vector<Carte*> cartesEnMain):
    _pointsDeVie(pv), _name(nom), _manaTotal(0), _mana(0), _hand(cartesEnMain) {}
    
    void Mage::playCard(int indexDansLaMain){
        _board.push_back(_hand[indexDansLaMain]);      
    }
    
    void Mage::regainMana(){
        _mana=_manaTotal;
    }


#endif